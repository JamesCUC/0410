# Smart Alarm Clock

A repository to kickstart your smart alarm clock project.

See [the howchoo Smart Alarm Clock guide](https://howchoo.com/g/zwq2zwixotu/how-to-make-a-raspberry-pi-smart-alarm-clock) for detailed instructions.
